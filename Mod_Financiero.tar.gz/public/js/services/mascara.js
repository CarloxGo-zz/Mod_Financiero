jQuery(function($){
      $("#codPartida").mask("9-99-99-99");
});