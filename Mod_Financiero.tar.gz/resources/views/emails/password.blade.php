<h1>Sistema de Movimientos presupuestarios</h1>
<center> <h3>Se ha solicitado un restablecimiento de su contraseña</h3>
<br>
 <a style="
	font-size: 13px;
    color: #ffffff;
	background-color: #4483c7; 
	background-image: -webkit-linear-gradient(#2e8dd5 0%, #5bbbeb 100%);
	background-image: -o-linear-gradient(#2e8dd5 0%, #5bbbeb 100%);
	background-image: linear-gradient(#2e8dd5 0%, #5bbbeb 100%);
	color: #FFF;
	text-decoration: none;
    padding: 11px 44px 10px;
    border: 1px solid #4483c7;
    display: inline-block;
 " href="<% url('password/reset/'.$token) %>" "email me">Restablecer contraseña</a>
<br><br>
<h5>
Si no realizó esta solicitud sientase libre de ignorar este mensaje.<br>
Su cuenta se mantiene segura</h5>
</center>