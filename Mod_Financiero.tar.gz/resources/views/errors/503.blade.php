
        <div class="container">
            <div class="content">
                <div class="title">Voveremos en un momentos.</div>
            </div>
        </div>
        <div class="col-md-11 col-md-offset-1">
      <a href="<%URL::previous()%>" title="Volver" class="btn btn-info pull- left">Volver</a>      
    </div>
    
